// Netlify Function: Compliance Summary
const https = require('https');

const PHILLY_API_BASE = 'https://services.arcgis.com/fLeGjb7u4uXqeF9q/arcgis/rest/services/lhhp_lead_certifications/FeatureServer/0';
const cache = new Map();
const CACHE_TTL = 3600000; // 1 hour for summary data

const headers = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'Content-Type',
  'Access-Control-Allow-Methods': 'GET, OPTIONS',
  'Content-Type': 'application/json'
};

function determineComplianceStatus(item) {
  const now = new Date();
  const expiryDate = item.cert_expiry || item.CERT_EXPIRY || item.expiry_date;
  
  if (!expiryDate || expiryDate === 'Permanent') {
    return item.cert_type || item.CERT_TYPE ? 'In Compliance' : 'Non-Compliant';
  }
  
  const expiry = new Date(expiryDate);
  return expiry < now ? 'Non-Compliant' : 'In Compliance';
}

function isExpiringSoon(expiryDate) {
  if (!expiryDate || expiryDate === 'Permanent') return false;
  
  const now = new Date();
  const expiry = new Date(expiryDate);
  const sixMonthsFromNow = new Date(now.getFullYear(), now.getMonth() + 6, now.getDate());
  
  return expiry <= sixMonthsFromNow && expiry > now;
}

async function fetchSummaryFromAPI() {
  return new Promise((resolve, reject) => {
    const params = new URLSearchParams({
      where: '1=1',
      outFields: 'cert_type,CERT_TYPE,cert_expiry,CERT_EXPIRY,compliance_status',
      f: 'json',
      returnGeometry: 'false',
      resultRecordCount: '2000' // Increased to get more comprehensive data
    });
    
    const url = `${PHILLY_API_BASE}/query?${params}`;

    https.get(url, (res) => {
      let data = '';
      res.on('data', (chunk) => data += chunk);
      res.on('end', () => {
        try {
          const parsed = JSON.parse(data);
          if (parsed.error) {
            reject(new Error(parsed.error.message || 'API Error'));
          } else {
            const rawData = parsed.features?.map(f => f.attributes) || [];
            
            const summary = {
              total: rawData.length,
              inCompliance: 0,
              nonCompliant: 0,
              expiringSoon: 0,
              leadFree: 0,
              leadSafe: 0,
              noTest: 0,
              lastUpdated: new Date().toISOString(),
              breakdown: {
                byType: {},
                byStatus: {},
                byComplianceStatus: {}
              }
            };

            rawData.forEach(item => {
              const complianceStatus = determineComplianceStatus(item);
              const certType = item.cert_type || item.CERT_TYPE || '';
              const expiryDate = item.cert_expiry || item.CERT_EXPIRY;

              // Count compliance status
              if (complianceStatus === 'In Compliance') {
                summary.inCompliance++;
              } else {
                summary.nonCompliant++;
              }

              // Count expiring soon
              if (isExpiringSoon(expiryDate)) {
                summary.expiringSoon++;
              }

              // Count by certification type
              if (certType === 'Lead Free') {
                summary.leadFree++;
              } else if (certType === 'Lead Safe') {
                summary.leadSafe++;
              } else if (!certType) {
                summary.noTest++;
              }

              // Build breakdown data
              summary.breakdown.byType[certType || 'No Test'] = 
                (summary.breakdown.byType[certType || 'No Test'] || 0) + 1;
              
              summary.breakdown.byComplianceStatus[complianceStatus] = 
                (summary.breakdown.byComplianceStatus[complianceStatus] || 0) + 1;
            });

            resolve(summary);
          }
        } catch (error) {
          reject(new Error('Failed to parse API response'));
        }
      });
    }).on('error', (error) => {
      reject(new Error(`API request failed: ${error.message}`));
    });
  });
}

exports.handler = async (event, context) => {
  // Handle CORS preflight
  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers };
  }

  try {
    // Check cache first
    const cacheKey = 'summary:all';
    const cached = cache.get(cacheKey);
    if (cached && (Date.now() - cached.timestamp) < CACHE_TTL) {
      return {
        statusCode: 200,
        headers,
        body: JSON.stringify(cached.data)
      };
    }

    console.log('Generating compliance summary from Philadelphia API');

    // Fetch fresh data from Philadelphia API
    const summary = await fetchSummaryFromAPI();

    // Cache the result
    cache.set(cacheKey, { 
      data: summary, 
      timestamp: Date.now() 
    });

    // Clean old cache entries
    if (cache.size > 50) {
      const oldestKey = cache.keys().next().value;
      cache.delete(oldestKey);
    }

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify(summary)
    };

  } catch (error) {
    console.error('Summary generation error:', error);
    
    // Return a basic summary if API fails
    const fallbackSummary = {
      total: 0,
      inCompliance: 0,
      nonCompliant: 0,
      expiringSoon: 0,
      leadFree: 0,
      leadSafe: 0,
      noTest: 0,
      error: 'Unable to fetch current data from Philadelphia API',
      lastUpdated: new Date().toISOString()
    };

    return {
      statusCode: 503,
      headers,
      body: JSON.stringify({
        error: 'Failed to generate compliance summary',
        details: error.message,
        fallback: fallbackSummary
      })
    };
  }
};