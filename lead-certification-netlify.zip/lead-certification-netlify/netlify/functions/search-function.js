// Netlify Function: Search Lead Certifications
const https = require('https');

// Configuration
const PHILLY_API_BASE = 'https://services.arcgis.com/fLeGjb7u4uXqeF9q/arcgis/rest/services/lhhp_lead_certifications/FeatureServer/0';
const CACHE_TTL = 900000; // 15 minutes in milliseconds

// In-memory cache (in production, use Redis or similar)
const cache = new Map();

// CORS headers
const headers = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'Content-Type',
  'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
  'Content-Type': 'application/json'
};

// Utility functions
function normalizeAddress(address) {
  if (!address) return '';
  
  return address
    .toUpperCase()
    .replace(/\b(STREET|ST)\b/g, 'ST')
    .replace(/\b(AVENUE|AVE)\b/g, 'AVE')
    .replace(/\b(BOULEVARD|BLVD)\b/g, 'BLVD')
    .replace(/\b(ROAD|RD)\b/g, 'RD')
    .replace(/\b(PLACE|PL)\b/g, 'PL')
    .replace(/\b(NORTH|N)\b/g, 'N')
    .replace(/\b(SOUTH|S)\b/g, 'S')
    .replace(/\b(EAST|E)\b/g, 'E')
    .replace(/\b(WEST|W)\b/g, 'W')
    .replace(/[^\w\s]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

function determineComplianceStatus(item) {
  const now = new Date();
  const expiryDate = item.cert_expiry || item.CERT_EXPIRY || item.expiry_date;
  
  if (!expiryDate || expiryDate === 'Permanent') {
    return item.cert_type || item.CERT_TYPE ? 'In Compliance' : 'Non-Compliant';
  }
  
  const expiry = new Date(expiryDate);
  if (expiry < now) {
    return 'Non-Compliant';
  }
  
  return 'In Compliance';
}

function transformLeadData(rawData) {
  if (!Array.isArray(rawData)) return [];
  
  return rawData.map(item => ({
    opa_account_num: item.opa_account_num || item.OPA_ACCOUNT_NUM || item.account_num || '',
    property_address: item.property_address || item.PROPERTY_ADDRESS || item.address || '',
    unit_address: item.unit_address || item.UNIT_ADDRESS || item.unit || '',
    cert_type: item.cert_type || item.CERT_TYPE || item.certification_type || '',
    cert_status: item.cert_status || item.CERT_STATUS || item.status || '',
    cert_date: item.cert_date || item.CERT_DATE || item.certification_date || '',
    cert_expiry: item.cert_expiry || item.CERT_EXPIRY || item.expiry_date || '',
    sampling_date: item.sampling_date || item.SAMPLING_DATE || item.test_date || '',
    inspector_company: item.inspector_company || item.INSPECTOR_COMPANY || item.vendor || '',
    compliance_status: determineComplianceStatus(item),
    lead_test_done: (item.cert_type || item.CERT_TYPE) ? 'Yes' : 'No'
  }));
}

async function fetchFromPhillyAPI(whereClause) {
  return new Promise((resolve, reject) => {
    const params = new URLSearchParams({
      where: whereClause,
      outFields: '*',
      f: 'json',
      returnGeometry: 'false'
    });
    
    const url = `${PHILLY_API_BASE}/query?${params}`;
    
    https.get(url, (res) => {
      let data = '';
      res.on('data', (chunk) => data += chunk);
      res.on('end', () => {
        try {
          const parsed = JSON.parse(data);
          if (parsed.error) {
            reject(new Error(parsed.error.message || 'API Error'));
          } else {
            const rawData = parsed.features?.map(f => f.attributes) || [];
            resolve(transformLeadData(rawData));
          }
        } catch (error) {
          reject(new Error('Failed to parse API response'));
        }
      });
    }).on('error', (error) => {
      reject(new Error(`API request failed: ${error.message}`));
    });
  });
}

exports.handler = async (event, context) => {
  // Handle CORS preflight
  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers };
  }

  try {
    const { address, opaAccount } = event.queryStringParameters || {};
    
    if (!address && !opaAccount) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ 
          error: 'Either address or opaAccount parameter is required' 
        })
      };
    }

    // Check cache
    const cacheKey = `search:${address || opaAccount}`;
    const cached = cache.get(cacheKey);
    if (cached && (Date.now() - cached.timestamp) < CACHE_TTL) {
      return {
        statusCode: 200,
        headers,
        body: JSON.stringify(cached.data)
      };
    }

    // Build where clause
    let whereClause;
    if (opaAccount) {
      whereClause = `opa_account_num='${opaAccount}' OR OPA_ACCOUNT_NUM='${opaAccount}'`;
    } else {
      const normalizedAddress = normalizeAddress(address);
      whereClause = `UPPER(property_address) LIKE '%${normalizedAddress}%' OR UPPER(PROPERTY_ADDRESS) LIKE '%${normalizedAddress}%'`;
    }

    console.log('Searching with clause:', whereClause);

    // Fetch from Philadelphia API
    const results = await fetchFromPhillyAPI(whereClause);

    // Cache results
    cache.set(cacheKey, {
      data: results,
      timestamp: Date.now()
    });

    // Clean old cache entries (simple cleanup)
    if (cache.size > 100) {
      const oldestKey = cache.keys().next().value;
      cache.delete(oldestKey);
    }

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify(results)
    };

  } catch (error) {
    console.error('Search function error:', error);
    
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        error: 'Failed to fetch lead certification data',
        details: error.message
      })
    };
  }
};