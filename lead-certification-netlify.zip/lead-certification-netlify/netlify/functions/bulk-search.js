// Netlify Function: Bulk Search Lead Certifications
const https = require('https');

const PHILLY_API_BASE = 'https://services.arcgis.com/fLeGjb7u4uXqeF9q/arcgis/rest/services/lhhp_lead_certifications/FeatureServer/0';

const headers = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'Content-Type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
  'Content-Type': 'application/json'
};

function normalizeAddress(address) {
  if (!address) return '';
  return address
    .toUpperCase()
    .replace(/\b(STREET|ST)\b/g, 'ST')
    .replace(/\b(AVENUE|AVE)\b/g, 'AVE')
    .replace(/\b(BOULEVARD|BLVD)\b/g, 'BLVD')
    .replace(/\b(ROAD|RD)\b/g, 'RD')
    .replace(/\b(PLACE|PL)\b/g, 'PL')
    .replace(/\b(NORTH|N)\b/g, 'N')
    .replace(/\b(SOUTH|S)\b/g, 'S')
    .replace(/\b(EAST|E)\b/g, 'E')
    .replace(/\b(WEST|W)\b/g, 'W')
    .replace(/[^\w\s]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

function determineComplianceStatus(item) {
  const now = new Date();
  const expiryDate = item.cert_expiry || item.CERT_EXPIRY || item.expiry_date;
  
  if (!expiryDate || expiryDate === 'Permanent') {
    return item.cert_type || item.CERT_TYPE ? 'In Compliance' : 'Non-Compliant';
  }
  
  const expiry = new Date(expiryDate);
  return expiry < now ? 'Non-Compliant' : 'In Compliance';
}

function transformProperty(item) {
  return {
    opa_account_num: item.opa_account_num || item.OPA_ACCOUNT_NUM || item.account_num || '',
    property_address: item.property_address || item.PROPERTY_ADDRESS || item.address || '',
    unit_address: item.unit_address || item.UNIT_ADDRESS || item.unit || '',
    cert_type: item.cert_type || item.CERT_TYPE || item.certification_type || '',
    cert_status: item.cert_status || item.CERT_STATUS || item.status || '',
    cert_date: item.cert_date || item.CERT_DATE || item.certification_date || '',
    cert_expiry: item.cert_expiry || item.CERT_EXPIRY || item.expiry_date || '',
    sampling_date: item.sampling_date || item.SAMPLING_DATE || item.test_date || '',
    inspector_company: item.inspector_company || item.INSPECTOR_COMPANY || item.vendor || '',
    compliance_status: determineComplianceStatus(item),
    lead_test_done: (item.cert_type || item.CERT_TYPE) ? 'Yes' : 'No'
  };
}

async function searchSingleProperty(property) {
  return new Promise((resolve) => {
    try {
      const { address, opaAccount } = property;
      
      let whereClause;
      if (opaAccount) {
        whereClause = `opa_account_num='${opaAccount}' OR OPA_ACCOUNT_NUM='${opaAccount}'`;
      } else if (address) {
        const normalizedAddress = normalizeAddress(address);
        whereClause = `UPPER(property_address) LIKE '%${normalizedAddress}%' OR UPPER(PROPERTY_ADDRESS) LIKE '%${normalizedAddress}%'`;
      } else {
        return resolve({ 
          input: property, 
          error: 'Address or OPA account required',
          found: false 
        });
      }

      const params = new URLSearchParams({
        where: whereClause,
        outFields: '*',
        f: 'json',
        returnGeometry: 'false'
      });
      
      const url = `${PHILLY_API_BASE}/query?${params}`;

      https.get(url, (res) => {
        let data = '';
        res.on('data', (chunk) => data += chunk);
        res.on('end', () => {
          try {
            const parsed = JSON.parse(data);
            if (parsed.error) {
              resolve({ 
                input: property, 
                error: parsed.error.message, 
                found: false 
              });
            } else {
              const rawData = parsed.features?.map(f => f.attributes) || [];
              const transformedData = rawData.map(transformProperty);
              resolve({
                input: property,
                results: transformedData,
                found: transformedData.length > 0
              });
            }
          } catch (error) {
            resolve({ 
              input: property, 
              error: error.message, 
              found: false 
            });
          }
        });
      }).on('error', (error) => {
        resolve({ 
          input: property, 
          error: error.message, 
          found: false 
        });
      });
    } catch (error) {
      resolve({ 
        input: property, 
        error: error.message, 
        found: false 
      });
    }
  });
}

exports.handler = async (event, context) => {
  // Handle CORS preflight
  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers };
  }

  try {
    const requestBody = JSON.parse(event.body || '{}');
    const { properties } = requestBody;
    
    if (!Array.isArray(properties) || properties.length === 0) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ 
          error: 'Properties array is required' 
        })
      };
    }

    if (properties.length > 50) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ 
          error: 'Maximum 50 properties per bulk request' 
        })
      };
    }

    console.log(`Processing bulk search for ${properties.length} properties`);

    const results = [];
    
    // Process in batches of 5 to avoid overwhelming the API
    const batchSize = 5;
    for (let i = 0; i < properties.length; i += batchSize) {
      const batch = properties.slice(i, i + batchSize);
      
      // Process batch in parallel
      const batchPromises = batch.map(searchSingleProperty);
      const batchResults = await Promise.all(batchPromises);
      results.push(...batchResults);
      
      // Add delay between batches to be respectful to the API
      if (i + batchSize < properties.length) {
        await new Promise(resolve => setTimeout(resolve, 1000));
      }
    }

    const summary = {
      totalRequested: properties.length,
      totalFound: results.filter(r => r.found).length,
      totalErrors: results.filter(r => r.error).length,
      results
    };

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify(summary)
    };

  } catch (error) {
    console.error('Bulk search error:', error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        error: 'Failed to process bulk request',
        details: error.message
      })
    };
  }
};