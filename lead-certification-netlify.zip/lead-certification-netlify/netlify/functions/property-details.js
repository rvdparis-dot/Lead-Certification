// Netlify Function: Get Property Details by OPA Account
const https = require('https');

const PHILLY_API_BASE = 'https://services.arcgis.com/fLeGjb7u4uXqeF9q/arcgis/rest/services/lhhp_lead_certifications/FeatureServer/0';
const cache = new Map();
const CACHE_TTL = 900000; // 15 minutes

const headers = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'Content-Type',
  'Access-Control-Allow-Methods': 'GET, OPTIONS',
  'Content-Type': 'application/json'
};

function determineComplianceStatus(item) {
  const now = new Date();
  const expiryDate = item.cert_expiry || item.CERT_EXPIRY || item.expiry_date;
  
  if (!expiryDate || expiryDate === 'Permanent') {
    return item.cert_type || item.CERT_TYPE ? 'In Compliance' : 'Non-Compliant';
  }
  
  const expiry = new Date(expiryDate);
  return expiry < now ? 'Non-Compliant' : 'In Compliance';
}

function transformProperty(item) {
  return {
    opa_account_num: item.opa_account_num || item.OPA_ACCOUNT_NUM || item.account_num || '',
    property_address: item.property_address || item.PROPERTY_ADDRESS || item.address || '',
    unit_address: item.unit_address || item.UNIT_ADDRESS || item.unit || '',
    cert_type: item.cert_type || item.CERT_TYPE || item.certification_type || '',
    cert_status: item.cert_status || item.CERT_STATUS || item.status || '',
    cert_date: item.cert_date || item.CERT_DATE || item.certification_date || '',
    cert_expiry: item.cert_expiry || item.CERT_EXPIRY || item.expiry_date || '',
    sampling_date: item.sampling_date || item.SAMPLING_DATE || item.test_date || '',
    inspector_company: item.inspector_company || item.INSPECTOR_COMPANY || item.vendor || '',
    compliance_status: determineComplianceStatus(item),
    lead_test_done: (item.cert_type || item.CERT_TYPE) ? 'Yes' : 'No'
  };
}

async function fetchPropertyFromAPI(opaAccount) {
  return new Promise((resolve, reject) => {
    const whereClause = `opa_account_num='${opaAccount}' OR OPA_ACCOUNT_NUM='${opaAccount}'`;
    const params = new URLSearchParams({
      where: whereClause,
      outFields: '*',
      f: 'json',
      returnGeometry: 'false'
    });
    
    const url = `${PHILLY_API_BASE}/query?${params}`;

    https.get(url, (res) => {
      let data = '';
      res.on('data', (chunk) => data += chunk);
      res.on('end', () => {
        try {
          const parsed = JSON.parse(data);
          if (parsed.error) {
            reject(new Error(parsed.error.message || 'API Error'));
          } else {
            const rawData = parsed.features?.map(f => f.attributes) || [];
            if (rawData.length === 0) {
              resolve(null);
            } else {
              resolve(transformProperty(rawData[0]));
            }
          }
        } catch (error) {
          reject(new Error('Failed to parse API response'));
        }
      });
    }).on('error', (error) => {
      reject(new Error(`API request failed: ${error.message}`));
    });
  });
}

exports.handler = async (event, context) => {
  // Handle CORS preflight
  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers };
  }

  try {
    // Extract OPA account from path
    const pathSegments = event.path.split('/');
    const opaAccount = pathSegments[pathSegments.length - 1];
    
    if (!opaAccount) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ error: 'OPA Account Number is required' })
      };
    }

    // Check cache
    const cacheKey = `property:${opaAccount}`;
    const cached = cache.get(cacheKey);
    if (cached && (Date.now() - cached.timestamp) < CACHE_TTL) {
      return {
        statusCode: 200,
        headers,
        body: JSON.stringify(cached.data)
      };
    }

    console.log('Fetching property details for OPA:', opaAccount);

    // Fetch from Philadelphia API
    const result = await fetchPropertyFromAPI(opaAccount);

    if (!result) {
      return {
        statusCode: 404,
        headers,
        body: JSON.stringify({ 
          error: 'Property not found', 
          opaAccount 
        })
      };
    }

    // Cache the result
    cache.set(cacheKey, { 
      data: result, 
      timestamp: Date.now() 
    });

    // Clean old cache entries
    if (cache.size > 100) {
      const oldestKey = cache.keys().next().value;
      cache.delete(oldestKey);
    }

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify(result)
    };

  } catch (error) {
    console.error('Property details error:', error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        error: 'Failed to fetch property details',
        details: error.message
      })
    };
  }
};