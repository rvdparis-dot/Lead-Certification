// Lead Certification Lookup - Main JavaScript
class LeadCertificationApp {
    constructor() {
        this.searchInput = document.getElementById('search-input');
        this.searchBtn = document.getElementById('search-btn');
        this.loading = document.getElementById('loading');
        this.errorMessage = document.getElementById('error-message');
        this.errorText = document.getElementById('error-text');
        this.statsSection = document.getElementById('stats-section');
        this.resultsSection = document.getElementById('results-section');
        this.resultsTitle = document.getElementById('results-title');
        this.resultsContainer = document.getElementById('results-container');
        this.noResults = document.getElementById('no-results');
        
        // CSV Upload elements
        this.csvFileInput = document.getElementById('csv-file-input');
        this.uploadArea = document.getElementById('upload-area');
        this.uploadStatus = document.getElementById('upload-status');
        this.progressFill = document.getElementById('progress-fill');
        this.progressText = document.getElementById('progress-text');
        
        this.currentResults = [];
        this.currentSearchType = 'single'; // 'single' or 'bulk'
        this.init();
    }

    init() {
        this.bindEvents();
        this.loadSampleDataForDemo();
        this.checkAPIStatus();
        this.updateStatusDisplay();
    }

    updateStatusDisplay() {
        // Show current URL
        const urlSpan = document.getElementById('current-url');
        if (urlSpan) {
            urlSpan.textContent = window.location.href;
        }

        // Show demo mode status
        const demoStatus = document.getElementById('demo-status');
        if (demoStatus) {
            if (this.demoMode) {
                demoStatus.innerHTML = '🎭 <strong>ENABLED</strong> (using sample data)';
                demoStatus.style.color = '#d97706';
            } else {
                demoStatus.innerHTML = '❌ Disabled (using real API)';
                demoStatus.style.color = '#059669';
            }
        }
    }

    async checkAPIStatus() {
        const statusText = document.getElementById('api-status-text');
        if (statusText) statusText.textContent = 'Testing...';
        
        // Test if the API is working
        try {
            const response = await fetch('/.netlify/functions/search-certifications?address=test', {
                method: 'GET',
                signal: AbortSignal.timeout(5000) // 5 second timeout
            });
            
            if (response.status === 400) {
                // This is expected - we sent invalid params but the function responded
                console.log('✅ API Status: Functions are deployed and responding');
                this.showAPIStatus('ready');
                if (statusText) statusText.textContent = '✅ API Ready - Functions deployed and working';
            } else if (response.ok) {
                console.log('✅ API Status: Functions are working');
                this.showAPIStatus('ready');
                if (statusText) statusText.textContent = '✅ API Ready - Connected to Philadelphia database';
            } else {
                console.warn('⚠️ API Status: Functions responding but with errors');
                this.showAPIStatus('warning');
                if (statusText) statusText.textContent = '⚠️ API Warning - Functions deployed but may have issues';
            }
        } catch (error) {
            console.error('❌ API Status: Functions not available:', error.message);
            this.showAPIStatus('error');
            if (statusText) statusText.textContent = '❌ API Error - Functions not deployed or not working';
        }
    }

    switchTab(tabName) {
        // Update tab buttons
        const singleTab = document.getElementById('single-search-tab');
        const bulkTab = document.getElementById('bulk-search-tab');
        const singleContent = document.getElementById('single-search');
        const bulkContent = document.getElementById('bulk-search');

        if (tabName === 'single') {
            singleTab.classList.add('active');
            bulkTab.classList.remove('active');
            singleContent.classList.remove('hidden');
            bulkContent.classList.add('hidden');
            this.currentSearchType = 'single';
        } else {
            bulkTab.classList.add('active');
            singleTab.classList.remove('active');
            bulkContent.classList.remove('hidden');
            singleContent.classList.add('hidden');
            this.currentSearchType = 'bulk';
        }

        // Clear previous results when switching tabs
        this.hideResults();
        this.hideError();
    }

    // CSV Upload Handlers
    handleDragOver(e) {
        e.preventDefault();
        e.stopPropagation();
        this.uploadArea.classList.add('dragover');
    }

    handleDragLeave(e) {
        e.preventDefault();
        e.stopPropagation();
        this.uploadArea.classList.remove('dragover');
    }

    handleFileDrop(e) {
        e.preventDefault();
        e.stopPropagation();
        this.uploadArea.classList.remove('dragover');
        
        const files = e.dataTransfer.files;
        if (files.length > 0) {
            this.processCSVFile(files[0]);
        }
    }

    handleFileSelect(e) {
        const file = e.target.files[0];
        if (file) {
            this.processCSVFile(file);
        }
    }

    async processCSVFile(file) {
        console.log('📄 Processing CSV file:', file.name);
        
        if (!file.name.toLowerCase().endsWith('.csv')) {
            this.showError('❌ Please upload a CSV file (.csv extension)');
            return;
        }

        if (file.size > 5 * 1024 * 1024) { // 5MB limit
            this.showError('❌ File too large. Please upload a CSV file smaller than 5MB.');
            return;
        }

        try {
            this.showUploadProgress('Reading file...');
            
            const csvText = await this.readFileAsText(file);
            const properties = this.parseCSV(csvText);
            
            if (properties.length === 0) {
                this.showError('❌ No valid properties found in CSV. Please check the format.');
                return;
            }

            if (properties.length > 100) {
                this.showError('❌ Too many properties. Please limit to 100 properties per upload.');
                return;
            }

            console.log(`📊 Parsed ${properties.length} properties from CSV`);
            this.updateUploadProgress(20, `Found ${properties.length} properties...`);

            await this.processBulkSearch(properties);

        } catch (error) {
            console.error('CSV processing error:', error);
            this.showError(`❌ Error processing CSV: ${error.message}`);
            this.hideUploadProgress();
        }
    }

    readFileAsText(file) {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onload = (e) => resolve(e.target.result);
            reader.onerror = () => reject(new Error('Failed to read file'));
            reader.readAsText(file);
        });
    }

    parseCSV(csvText) {
        const lines = csvText.split('\n').map(line => line.trim()).filter(line => line);
        if (lines.length < 2) {
            throw new Error('CSV must have a header row and at least one data row');
        }

        const headers = lines[0].split(',').map(h => h.replace(/['"]/g, '').trim().toLowerCase());
        const properties = [];

        console.log('📋 CSV headers found:', headers);

        // Find address and OPA columns
        const addressIndex = headers.findIndex(h => h.includes('address'));
        const opaIndex = headers.findIndex(h => h.includes('opa') || h.includes('account'));

        if (addressIndex === -1 && opaIndex === -1) {
            throw new Error('CSV must have either "address" or "opa_account" column');
        }

        for (let i = 1; i < lines.length; i++) {
            const values = this.parseCSVLine(lines[i]);
            
            if (values.length < Math.max(addressIndex + 1, opaIndex + 1)) {
                continue; // Skip malformed rows
            }

            const property = {};
            
            if (addressIndex >= 0 && values[addressIndex]) {
                property.address = values[addressIndex].trim();
            }
            
            if (opaIndex >= 0 && values[opaIndex]) {
                property.opaAccount = values[opaIndex].trim();
            }

            // Skip rows with no valid data
            if (!property.address && !property.opaAccount) {
                continue;
            }

            properties.push(property);
        }

        return properties;
    }

    parseCSVLine(line) {
        const values = [];
        let current = '';
        let inQuotes = false;

        for (let i = 0; i < line.length; i++) {
            const char = line[i];
            
            if (char === '"') {
                inQuotes = !inQuotes;
            } else if (char === ',' && !inQuotes) {
                values.push(current.trim());
                current = '';
            } else {
                current += char;
            }
        }
        
        values.push(current.trim());
        return values.map(v => v.replace(/^["']|["']$/g, ''));
    }

    async processBulkSearch(properties) {
        console.log(`🔍 Starting bulk search for ${properties.length} properties`);
        
        try {
            this.updateUploadProgress(30, 'Sending bulk search request...');

            const response = await fetch('/.netlify/functions/bulk-search', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ properties })
            });

            if (!response.ok) {
                const errorData = await response.json().catch(() => ({}));
                throw new Error(errorData.error || `HTTP ${response.status}: ${response.statusText}`);
            }

            this.updateUploadProgress(80, 'Processing results...');
            const bulkResults = await response.json();
            
            console.log('📊 Bulk search completed:', bulkResults);
            
            // Flatten results for display
            const allResults = [];
            bulkResults.results.forEach(result => {
                if (result.results && result.results.length > 0) {
                    allResults.push(...result.results);
                }
            });

            this.updateUploadProgress(100, 'Complete!');
            
            setTimeout(() => {
                this.hideUploadProgress();
                if (allResults.length > 0) {
                    this.displayResults(allResults);
                    this.resultsTitle.textContent = `Bulk Search Results: ${allResults.length} properties found from ${properties.length} searched`;
                } else {
                    this.showNoResults();
                }
            }, 1000);

        } catch (error) {
            console.error('Bulk search error:', error);
            throw error;
        }
    }

    // Upload Progress Management
    showUploadProgress(message) {
        this.uploadStatus.classList.remove('hidden');
        this.progressText.textContent = message;
        this.progressFill.style.width = '0%';
    }

    updateUploadProgress(percent, message) {
        this.progressFill.style.width = `${percent}%`;
        this.progressText.textContent = message;
    }

    hideUploadProgress() {
        this.uploadStatus.classList.add('hidden');
        this.progressFill.style.width = '0%';
    }

    showAPIStatus(status) {
        const statusDiv = document.createElement('div');
        statusDiv.id = 'api-status';
        
        const messages = {
            ready: {
                bg: '#d1fae5',
                border: '#10b981', 
                color: '#065f46',
                icon: '✅',
                text: 'API Ready - Connected to Philadelphia lead certification database'
            },
            warning: {
                bg: '#fef3c7',
                border: '#f59e0b',
                color: '#92400e', 
                icon: '⚠️',
                text: 'API Warning - Functions deployed but may have issues'
            },
            error: {
                bg: '#fee2e2',
                border: '#ef4444',
                color: '#991b1b',
                icon: '❌',
                text: 'API Error - Netlify functions not deployed. Run "netlify dev" for local testing or deploy to Netlify.'
            }
        };

        const msg = messages[status];
        statusDiv.innerHTML = `
            <div style="background: ${msg.bg}; border: 1px solid ${msg.border}; color: ${msg.color}; padding: 0.75rem; margin: 1rem 0; border-radius: 8px; font-size: 0.875rem;">
                ${msg.icon} ${msg.text}
            </div>
        `;

        const container = document.querySelector('.container');
        const searchSection = document.querySelector('.search-section');
        container.insertBefore(statusDiv, searchSection);

        // Auto-hide success message after 3 seconds
        if (status === 'ready') {
            setTimeout(() => {
                statusDiv.style.transition = 'opacity 0.5s';
                statusDiv.style.opacity = '0';
                setTimeout(() => statusDiv.remove(), 500);
            }, 3000);
        }
    }

    async testAPI() {
        console.log('🔧 Testing API endpoints...');
        
        // Show loading state
        const testBtn = document.getElementById('test-api-btn');
        const originalText = testBtn.querySelector('.btn-text').textContent;
        testBtn.querySelector('.btn-text').textContent = 'Testing...';
        testBtn.disabled = true;
        
        this.hideError();
        
        const tests = [
            {
                name: 'Search Function',
                url: '/.netlify/functions/search-certifications?address=test',
                expected: [200, 400, 500] // 400/500 are ok if function exists but fails
            },
            {
                name: 'Property Details',
                url: '/.netlify/functions/property-details/123456789',
                expected: [200, 404, 500] // 404/500 are ok if function exists
            },
            {
                name: 'Compliance Summary',
                url: '/.netlify/functions/compliance-summary',
                expected: [200, 500, 503] // 500/503 if API is down but function works
            }
        ];

        let results = [];
        let anySuccess = false;
        
        for (const test of tests) {
            try {
                console.log(`🧪 Testing ${test.name}...`);
                
                const startTime = Date.now();
                const response = await fetch(test.url, {
                    signal: AbortSignal.timeout(10000) // 10 second timeout
                });
                const duration = Date.now() - startTime;
                
                const status = response.status;
                const statusText = response.statusText;
                
                console.log(`📊 ${test.name}: ${status} ${statusText} (${duration}ms)`);
                
                if (status === 404) {
                    results.push(`❌ ${test.name}: Function not deployed (404)`);
                } else if (test.expected.includes(status)) {
                    results.push(`✅ ${test.name}: Working (${status}) - ${duration}ms`);
                    anySuccess = true;
                } else {
                    results.push(`⚠️ ${test.name}: Unexpected response (${status})`);
                }
                
                // Try to get response body for debugging
                if (status !== 404) {
                    try {
                        const responseText = await response.text();
                        console.log(`📄 ${test.name} response:`, responseText.substring(0, 200));
                    } catch (e) {
                        // Ignore response parsing errors
                    }
                }
                
            } catch (error) {
                console.error(`❌ ${test.name} failed:`, error);
                if (error.name === 'TimeoutError') {
                    results.push(`⏰ ${test.name}: Timeout (>10s)`);
                } else if (error.message.includes('Failed to fetch')) {
                    results.push(`🌐 ${test.name}: Network error / CORS issue`);
                } else {
                    results.push(`❌ ${test.name}: ${error.message}`);
                }
            }
        }

        // Generate detailed report
        let message = `🧪 API Test Results:\n\n${results.join('\n')}\n\n`;
        
        if (!anySuccess) {
            message += `🚨 DIAGNOSIS: Functions not deployed or not accessible\n\n`;
            message += `🔧 Solutions:\n`;
            message += `• Deploy via GitHub: Most reliable method\n`;
            message += `• Local testing: Run "netlify dev" in terminal\n`;
            message += `• Direct deployment: Drag functions folder to Netlify\n`;
            message += `• Check Netlify dashboard → Functions tab\n\n`;
            message += `🔗 Function URLs should be:\n`;
            message += `• ${window.location.origin}/.netlify/functions/search-certifications\n`;
            message += `• ${window.location.origin}/.netlify/functions/property-details\n`;
            message += `• ${window.location.origin}/.netlify/functions/compliance-summary\n`;
        } else {
            message += `✅ DIAGNOSIS: Some functions are working!\n\n`;
            message += `💡 If searches still fail:\n`;
            message += `• Check browser console for specific errors\n`;
            message += `• Verify Philadelphia API is accessible\n`;
            message += `• Test with different addresses\n`;
        }

        this.showError(message);
        
        // Reset button
        testBtn.querySelector('.btn-text').textContent = originalText;
        testBtn.disabled = false;
    }

    bindEvents() {
        // Single search events
        this.searchBtn.addEventListener('click', () => this.handleSearch());
        
        // Test API button
        const testApiBtn = document.getElementById('test-api-btn');
        if (testApiBtn) {
            testApiBtn.addEventListener('click', () => this.testAPI());
        }
        
        this.searchInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                this.handleSearch();
            }
        });
        
        // Prevent empty searches
        this.searchInput.addEventListener('input', () => {
            const hasValue = this.searchInput.value.trim().length > 0;
            this.searchBtn.disabled = !hasValue;
        });

        // Tab switching
        const singleTab = document.getElementById('single-search-tab');
        const bulkTab = document.getElementById('bulk-search-tab');
        
        if (singleTab && bulkTab) {
            singleTab.addEventListener('click', () => this.switchTab('single'));
            bulkTab.addEventListener('click', () => this.switchTab('bulk'));
        }

        // CSV Upload events
        if (this.csvFileInput && this.uploadArea) {
            this.csvFileInput.addEventListener('change', (e) => this.handleFileSelect(e));
            
            const browseBtn = document.getElementById('browse-btn');
            if (browseBtn) {
                browseBtn.addEventListener('click', () => this.csvFileInput.click());
            }

            // Drag and drop
            this.uploadArea.addEventListener('click', () => this.csvFileInput.click());
            this.uploadArea.addEventListener('dragover', (e) => this.handleDragOver(e));
            this.uploadArea.addEventListener('dragleave', (e) => this.handleDragLeave(e));
            this.uploadArea.addEventListener('drop', (e) => this.handleFileDrop(e));
        }
    }

    async handleSearch() {
        const query = this.searchInput.value.trim();
        if (!query) return;

        console.log('🔍 Starting search for:', query);
        console.log('🔍 Demo mode active:', !!this.demoMode);

        this.showLoading();
        this.hideError();
        this.hideResults();

        try {
            const results = await this.searchCertifications(query);
            console.log('📊 Search completed. Results:', results);
            
            if (results && results.length > 0) {
                console.log(`✅ Found ${results.length} properties`);
                this.displayResults(results);
            } else {
                console.log('📭 No results found');
                this.showNoResults();
            }
        } catch (error) {
            console.error('❌ Search failed:', error);
            
            // Determine error type and show appropriate message
            if (error.message.includes('Failed to fetch') || error.message.includes('NetworkError')) {
                this.showError(`🌐 Network Error: Unable to connect to API endpoints.

🔧 This usually means:
• Netlify functions are not deployed
• You're testing locally without running "netlify dev"
• There's a network connectivity issue

📋 Next steps:
• Click "Test API" button for detailed diagnostics
• If local: run "netlify dev" in your terminal
• If deployed: check Netlify dashboard for function deployment status
• Add "?demo=true" to URL to test with sample data`);
            } else if (error.message.includes('404')) {
                this.showError(`🔍 API Not Found: The search endpoint doesn't exist.

🔧 This means:
• Netlify functions are not properly deployed
• The function files are missing or in wrong location

📋 Next steps:
• Ensure all files in "netlify/functions/" are deployed
• Check Netlify dashboard Functions tab
• Review the deployment logs for errors`);
            } else {
                this.showError(`⚠️ Search Error: ${error.message}

🔧 Troubleshooting:
• Click "Test API" button for diagnostics
• Check browser console for detailed errors
• Verify the Philadelphia API is accessible`);
            }
        } finally {
            this.hideLoading();
        }
    }

    async searchCertifications(query) {
        // This function is ONLY overridden if demo mode is enabled
        // Otherwise it uses the real API
        
        if (this.demoMode) {
            // This should never run unless ?demo=true is in URL
            console.error('❌ Demo mode active but should not be!');
            throw new Error('Demo mode is active. Remove ?demo=true from URL for real data.');
        }

        // REAL API CALL
        console.log('🌐 Making REAL API call for:', query);
        
        const isOPAAccount = /^\d+$/.test(query);
        const endpoint = '/.netlify/functions/search-certifications';
        
        const params = new URLSearchParams();
        if (isOPAAccount) {
            params.append('opaAccount', query);
        } else {
            params.append('address', query);
        }

        const url = `${endpoint}?${params}`;
        console.log('🔗 API URL:', url);

        const response = await fetch(url);
        
        console.log('📡 API Response Status:', response.status);
        
        if (!response.ok) {
            const errorData = await response.json().catch(() => ({}));
            const errorMsg = errorData.error || `HTTP ${response.status}: ${response.statusText}`;
            console.error('❌ API Error:', errorMsg);
            throw new Error(errorMsg);
        }

        const data = await response.json();
        console.log('✅ API Response Data:', data);
        return data;
    }

    displayResults(results) {
        this.currentResults = results;
        
        if (results.length === 0) {
            this.showNoResults();
            return;
        }

        this.updateStats(results);
        this.renderResults(results);
        this.showResults();
    }

    updateStats(results) {
        const stats = this.calculateStats(results);
        
        document.getElementById('compliant-count').textContent = stats.compliant;
        document.getElementById('non-compliant-count').textContent = stats.nonCompliant;
        document.getElementById('expiring-count').textContent = stats.expiring;
        document.getElementById('total-count').textContent = stats.total;
        
        this.statsSection.classList.remove('hidden');
    }

    calculateStats(results) {
        const now = new Date();
        const sixMonthsFromNow = new Date(now.getFullYear(), now.getMonth() + 6, now.getDate());
        
        return {
            total: results.length,
            compliant: results.filter(r => r.compliance_status === 'In Compliance').length,
            nonCompliant: results.filter(r => r.compliance_status === 'Non-Compliant').length,
            expiring: results.filter(r => this.isExpiringSoon(r.cert_expiry, sixMonthsFromNow)).length
        };
    }

    renderResults(results) {
        const template = document.getElementById('property-template');
        this.resultsContainer.innerHTML = '';
        
        results.forEach(property => {
            const card = this.createPropertyCard(template, property);
            this.resultsContainer.appendChild(card);
        });
        
        this.resultsTitle.textContent = `Found ${results.length} certification record(s)`;
    }

    createPropertyCard(template, property) {
        const card = template.content.cloneNode(true);
        
        // Basic property info
        card.querySelector('.property-address').textContent = property.property_address;
        card.querySelector('.property-unit').textContent = property.unit_address || '';
        card.querySelector('.opa-number').textContent = property.opa_account_num;
        
        // Status badge
        const statusBadge = card.querySelector('.status-badge');
        statusBadge.textContent = property.compliance_status;
        statusBadge.className = `status-badge ${this.getStatusClass(property.compliance_status)}`;
        
        // Expiring soon badge
        const expiringBadge = card.querySelector('.expiring-badge');
        if (this.isExpiringSoon(property.cert_expiry)) {
            expiringBadge.classList.remove('hidden');
        }
        
        // Detail fields
        card.querySelector('.lead-test-status').textContent = property.lead_test_done;
        card.querySelector('.cert-type').textContent = property.cert_type;
        
        // Dates
        const samplingDate = card.querySelector('.sampling-date .date-value');
        const certDate = card.querySelector('.cert-date .date-value');
        const expiryDate = card.querySelector('.expiry-date .date-value');
        
        samplingDate.textContent = this.formatDate(property.sampling_date);
        certDate.textContent = this.formatDate(property.cert_date);
        expiryDate.textContent = this.formatDate(property.cert_expiry);
        
        // Add expiring class to expiry date if needed
        if (this.isExpiringSoon(property.cert_expiry)) {
            expiryDate.parentElement.style.color = '#d97706';
            expiryDate.parentElement.style.fontWeight = '600';
        }
        
        // Vendor
        card.querySelector('.vendor-value').textContent = property.inspector_company;
        
        // Show action buttons for non-compliant properties
        const actionsDiv = card.querySelector('.property-actions');
        if (property.compliance_status !== 'In Compliance') {
            actionsDiv.classList.remove('hidden');
            
            // Store property data on buttons for action handlers
            const buttons = actionsDiv.querySelectorAll('button');
            buttons.forEach(btn => {
                btn.dataset.property = JSON.stringify(property);
            });
        }
        
        return card;
    }

    getStatusClass(status) {
        if (status === 'In Compliance') return 'compliant';
        if (status === 'Non-Compliant') return 'non-compliant';
        return 'expiring';
    }

    isExpiringSoon(expiryDate, referenceDate = null) {
        if (!expiryDate || expiryDate === 'Permanent') return false;
        
        const expiry = new Date(expiryDate);
        const now = referenceDate || new Date();
        const sixMonthsFromNow = new Date(now.getFullYear(), now.getMonth() + 6, now.getDate());
        
        return expiry <= sixMonthsFromNow && expiry > now;
    }

    formatDate(dateString) {
        if (!dateString || dateString === 'Permanent') return dateString;
        
        try {
            return new Date(dateString).toLocaleDateString('en-US', {
                year: 'numeric',
                month: 'short',
                day: 'numeric'
            });
        } catch (e) {
            return dateString;
        }
    }

    // UI State Management
    showLoading() {
        this.loading.classList.remove('hidden');
        this.searchBtn.disabled = true;
        this.searchBtn.querySelector('.btn-text').textContent = 'Searching...';
    }

    hideLoading() {
        this.loading.classList.add('hidden');
        this.searchBtn.disabled = false;
        this.searchBtn.querySelector('.btn-text').textContent = 'Search';
    }

    showError(message) {
        this.errorText.innerHTML = message.replace(/\n/g, '<br>');
        this.errorMessage.classList.remove('hidden');
    }

    hideError() {
        this.errorMessage.classList.add('hidden');
    }

    showResults() {
        this.resultsSection.classList.remove('hidden');
        this.noResults.classList.add('hidden');
    }

    hideResults() {
        this.resultsSection.classList.add('hidden');
        this.statsSection.classList.add('hidden');
        this.noResults.classList.add('hidden');
    }

    showNoResults() {
        this.noResults.classList.remove('hidden');
        this.resultsSection.classList.add('hidden');
        this.statsSection.classList.add('hidden');
    }

    // REMOVE ALL SAMPLE DATA - NO FALLBACKS
    loadSampleDataForDemo() {
        // Only enable sample data if explicitly requested via URL parameter
        if (window.location.search.includes('demo=true')) {
            console.warn('🎭 DEMO MODE: Using sample data instead of live API');
            this.demoMode = true;
            this.showDemoModeWarning();
            this.enableDemoMode();
        } else {
            console.log('🔴 LIVE MODE: No sample data fallbacks - all searches use real API');
            this.demoMode = false;
        }
    }

    enableDemoMode() {
        // This ONLY runs if ?demo=true is in URL
        this.sampleData = [
            {
                opa_account_num: '123456789',
                property_address: '1234 Market St, Philadelphia, PA 19107',
                unit_address: 'Unit 2A',
                cert_type: 'Lead Safe',
                cert_status: 'Valid',
                cert_date: '2024-03-15',
                cert_expiry: '2028-03-15',
                sampling_date: '2024-03-10',
                inspector_company: 'SafeHome Testing LLC',
                compliance_status: 'In Compliance',
                lead_test_done: 'Yes'
            }
        ];

        // Override search function ONLY in demo mode
        this.searchCertifications = async (query) => {
            console.log('🎭 Demo mode: filtering sample data for:', query);
            await new Promise(resolve => setTimeout(resolve, 1000)); // Simulate API delay
            const filtered = this.sampleData.filter(property => 
                property.property_address.toLowerCase().includes(query.toLowerCase()) ||
                property.opa_account_num.includes(query)
            );
            return filtered;
        };
    }

    showDemoModeWarning() {
        const warning = document.createElement('div');
        warning.innerHTML = `
            <div style="background: #fef3c7; border: 2px solid #f59e0b; color: #92400e; padding: 1rem; margin: 1rem 0; border-radius: 8px; text-align: center;">
                🎭 <strong>DEMO MODE</strong> - Using sample data. Remove "?demo=true" from URL for live data.
            </div>
        `;
        document.querySelector('.container').insertBefore(warning, document.querySelector('.search-section'));
    }
}

// Action button handlers (called from HTML)
function scheduleRetesting(button) {
    const property = JSON.parse(button.dataset.property);
    alert(`Scheduling re-testing for ${property.property_address}. In a real app, this would open a scheduling form or redirect to a vendor portal.`);
}

function contactVendor(button) {
    const property = JSON.parse(button.dataset.property);
    alert(`Contacting ${property.inspector_company} about ${property.property_address}. In a real app, this would open an email client or contact form.`);
}

function viewDetails(button) {
    const property = JSON.parse(button.dataset.property);
    alert(`Viewing full details for ${property.property_address}. In a real app, this would open a detailed property view or PDF report.`);
}

function showDeploymentHelp() {
    const helpMessage = `🚀 DEPLOYMENT ALTERNATIVES TO GITHUB:

📦 Option 1: Correct ZIP Deployment
• Create folder with exact structure: netlify/functions/*.js
• ZIP the entire folder (not individual files)  
• Drag ZIP to Netlify deploy area
• Check Functions tab in dashboard after deploy

💻 Option 2: Netlify CLI
• Install: npm install -g netlify-cli
• Run: netlify login && netlify deploy --prod
• More reliable than drag-and-drop

🔧 Option 3: Local Testing First  
• Run: netlify dev
• Test at localhost:8888
• If local works, deployment should work

🌐 Option 4: Alternative Platforms
• Vercel.com (similar to Netlify)
• Cloudflare Pages + Workers

🔍 Current Diagnosis:
• Click "Test API" button to see what's failing
• Check browser console (F12) for error details
• Verify Functions tab in Netlify dashboard

💡 Quick Test:
Try this URL directly in browser:
${window.location.origin}/.netlify/functions/search-certifications?address=test

Expected: JSON response (not 404 error)
If 404: Functions not deployed correctly`;

    alert(helpMessage);
}

function showScheduleForm() {
    alert('Schedule Lead Testing form would open here. In a real app, this would redirect to a form or vendor booking system.');
}

// Initialize the app when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    new LeadCertificationApp();
});