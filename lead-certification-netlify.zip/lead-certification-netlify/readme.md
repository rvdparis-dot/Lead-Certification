# Philadelphia Lead Certification Lookup

A comprehensive web application for property management companies to proactively search and monitor lead certification compliance across their rental property portfolio in Philadelphia.

## 🏠 Overview

This tool connects directly to Philadelphia's official Lead Paint Certifications database via OpenDataPhilly.org, providing real-time access to lead certification status for rental properties. Built specifically for property managers who need to ensure compliance with Philadelphia's Lead Paint Disclosure and Certification Law.

## ✨ Features

### 🔍 **Smart Search**
- Search by property address or OPA account number
- Intelligent address normalization for better matching
- Real-time results from official city database

### 📊 **Compliance Dashboard**
- Visual overview of portfolio compliance status
- Quick stats: compliant, non-compliant, expiring soon
- Color-coded alerts for immediate action items

### 🏢 **Property Management Tools**
- Detailed certification history for each property
- Vendor contact information for re-testing
- Expiration date tracking and alerts
- Unit-level certification details

### 📈 **Bulk Operations**
- Upload multiple properties for batch processing
- CSV export capabilities for reporting
- Portfolio-wide compliance analysis

### 📱 **Mobile Responsive**
- Works perfectly on desktop, tablet, and mobile
- Optimized for field inspections and remote work

## 🚀 Quick Start

### Option 1: Deploy to Netlify (Recommended)

1. **Create the Project Structure**
   ```
   mkdir philadelphia-lead-lookup
   cd philadelphia-lead-lookup
   ```

2. **Add All Files** (copy each artifact to its location):
   ```
   lead-certification-netlify/
   ├── index.html
   ├── css/styles.css
   ├── js/main.js
   ├── netlify/functions/
   │   ├── search-certifications.js
   │   ├── property-details.js
   │   ├── bulk-search.js
   │   └── compliance-summary.js
   ├── netlify.toml
   ├── package.json
   └── README.md
   ```

3. **Deploy to Netlify**:
   - Push to GitHub/GitLab, OR
   - Drag & drop folder to [Netlify Dashboard](https://app.netlify.com)
   - Netlify auto-detects configuration from `netlify.toml`
   - Your app is live in seconds!

### Option 2: Local Development

1. **Install Netlify CLI**:
   ```bash
   npm install -g netlify-cli
   ```

2. **Setup Project**:
   ```bash
   git clone <your-repo>
   cd philadelphia-lead-lookup
   npm install
   ```

3. **Run Locally**:
   ```bash
   netlify dev
   ```
   - App: `http://localhost:8888`
   - Functions: `http://localhost:8888/.netlify/functions/`

## 🔧 API Endpoints

After deployment, your functions are available at:

```
GET  /.netlify/functions/search-certifications?address=Market St
GET  /.netlify/functions/search-certifications?opaAccount=123456789
GET  /.netlify/functions/property-details/123456789
POST /.netlify/functions/bulk-search
GET  /.netlify/functions/compliance-summary
```

### Example API Usage

**Search by Address:**
```bash
curl "https://your-site.netlify.app/.netlify/functions/search-certifications?address=1234%20Market%20St"
```

**Get Property Details:**
```bash
curl "https://your-site.netlify.app/.netlify/functions/property-details/123456789"
```

**Bulk Search:**
```bash
curl -X POST "https://your-site.netlify.app/.netlify/functions/bulk-search" \
  -H "Content-Type: application/json" \
  -d '{
    "properties": [
      {"address": "1234 Market St"},
      {"opaAccount": "123456789"}
    ]
  }'
```

## 📚 Data Source

### Philadelphia Lead Paint Certifications
- **Source**: City of Philadelphia Lead and Healthy Homes Program
- **Coverage**: All rental properties required to have lead certification
- **Update Frequency**: Real-time as certifications are submitted
- **API**: OpenDataPhilly.org ArcGIS REST Services
- **Data Fields**: Property address, OPA account, certification type, dates, vendor info, compliance status

### Legal Requirements
Philadelphia requires lead certification for:
- All rental properties built before 1978
- Properties housing children under 6 (regardless of building age)
- New or renewed rental licenses
- Must be "lead-safe" or "lead-free" certified

## 🏗️ Technical Architecture

### Frontend
- **Technology**: Vanilla HTML, CSS, JavaScript (no framework dependencies)
- **Styling**: Modern CSS Grid/Flexbox with responsive design
- **Performance**: Lightweight, fast loading, progressive enhancement

### Backend
- **Technology**: Netlify Functions (Node.js serverless)
- **Caching**: 15-minute cache for search results, 1-hour for summaries
- **Error Handling**: Comprehensive error responses with fallbacks
- **Rate Limiting**: Built-in protection against API abuse

### Hosting
- **Platform**: Netlify
- **CDN**: Global edge locations for fast access
- **SSL**: Automatic HTTPS certificates
- **Scaling**: Serverless auto-scaling based on demand

## 🛠️ Configuration

### Environment Variables
Set in Netlify Dashboard → Site Settings → Environment Variables:

```bash
# Optional - defaults work fine
OPENDATA_PHILLY_BASE_URL=https://services.arcgis.com/...
CACHE_TTL=900
MAX_BULK_PROPERTIES=50
DEBUG_LOGGING=false
```

### Customization
- **Styling**: Modify `css/styles.css` for branding
- **Functionality**: Extend `js/main.js` for custom features
- **API**: Add new functions in `netlify/functions/`

## 📊 Performance & Limits

### Caching Strategy
- **Search Results**: 15 minutes
- **Property Details**: 15 minutes  
- **Compliance Summary**: 1 hour
- **Static Assets**: 1 year (CSS/JS)

### API Limits
- **Bulk Search**: 50 properties per request
- **Rate Limiting**: 100 requests per 15 minutes per IP
- **Batch Processing**: 5 properties processed in parallel
- **Timeout**: 30 seconds per API call

## 🔒 Security

### Data Protection
- No sensitive data stored locally
- All API calls through secure HTTPS
- CORS properly configured
- XSS and content-type protection headers

### Privacy
- No user data collected or stored
- All searches are anonymous
- Connects only to official Philadelphia government data

## 🎯 Use Cases

### Property Management Companies
- **Portfolio Overview**: Monitor compliance across all properties
- **Lease Renewals**: Verify certifications before signing leases
- **Inspections**: Mobile access during property visits
- **Compliance Reports**: Generate reports for city inspections

### Real Estate Professionals
- **Due Diligence**: Research properties before purchase
- **Disclosure**: Verify lead status for buyer/seller disclosures
- **Investment Analysis**: Factor compliance costs into deals

### Landlords
- **License Renewals**: Ensure certifications are current
- **Tenant Relations**: Provide certification documentation
- **Maintenance Planning**: Schedule re-testing in advance

## 🤝 Contributing

### Development Setup
1. Fork the repository
2. Create feature branch: `git checkout -b feature-name`
3. Run locally: `netlify dev`
4. Test functions: `npm run test-functions`
5. Submit pull request

### Reporting Issues
- Use GitHub Issues for bug reports
- Include browser, URL, and steps to reproduce
- Screenshots help for UI issues

## 📄 License

MIT License - see LICENSE file for details.

## 🙋‍♂️ Support

### Documentation
- Check this README for common questions
- Review `netlify.toml` for configuration options
- Examine function code for API details

### Help
- **Technical Issues**: Open GitHub Issue
- **Philadelphia Data Questions**: Contact Lead and Healthy Homes Program
- **Netlify Deployment**: Check [Netlify Docs](https://docs.netlify.com)

### Updates
- Star/watch this repository for updates
- Philadelphia API changes are automatically handled
- New features announced in releases

---

**Built for Property Managers, by Property Management Professionals**

*This tool helps ensure compliance with Philadelphia's lead paint laws while protecting the health and safety of tenants across the city.*