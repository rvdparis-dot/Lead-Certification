// Test Script for Philadelphia Lead Certification Lookup Functions
// Run with: node test-functions.js

const https = require('https');
const http = require('http');

// Configuration
const LOCAL_BASE_URL = 'http://localhost:8888/.netlify/functions';
const PRODUCTION_BASE_URL = 'https://your-site.netlify.app/.netlify/functions';

// Use local URL by default, or set NODE_ENV=production for live testing
const BASE_URL = process.env.NODE_ENV === 'production' ? PRODUCTION_BASE_URL : LOCAL_BASE_URL;

// Test data
const TEST_DATA = {
  address: 'Market St',
  opaAccount: '123456789',
  bulkProperties: [
    { address: '1234 Market St' },
    { opaAccount: '123456789' },
    { address: '5678 Broad St' }
  ]
};

// Helper function to make HTTP requests
function makeRequest(url, options = {}) {
  return new Promise((resolve, reject) => {
    const isHttps = url.startsWith('https');
    const client = isHttps ? https : http;
    
    const requestOptions = {
      method: options.method || 'GET',
      headers: {
        'Content-Type': 'application/json',
        ...options.headers
      }
    };

    const req = client.request(url, requestOptions, (res) => {
      let data = '';
      res.on('data', (chunk) => data += chunk);
      res.on('end', () => {
        try {
          const result = {
            status: res.statusCode,
            headers: res.headers,
            data: data ? JSON.parse(data) : null
          };
          resolve(result);
        } catch (error) {
          resolve({
            status: res.statusCode,
            headers: res.headers,
            data: data,
            parseError: error.message
          });
        }
      });
    });

    req.on('error', reject);

    if (options.body) {
      req.write(JSON.stringify(options.body));
    }

    req.end();
  });
}

// Test functions
async function testSearchByAddress() {
  console.log('\n🔍 Testing search by address...');
  try {
    const url = `${BASE_URL}/search-certifications?address=${encodeURIComponent(TEST_DATA.address)}`;
    console.log(`   GET ${url}`);
    
    const response = await makeRequest(url);
    
    if (response.status === 200) {
      console.log('   ✅ Success:', `Found ${response.data?.length || 0} properties`);
      if (response.data && response.data.length > 0) {
        console.log('   📋 Sample result:', {
          address: response.data[0].property_address,
          compliance: response.data[0].compliance_status,
          opa: response.data[0].opa_account_num
        });
      }
    } else {
      console.log('   ❌ Failed:', response.status, response.data?.error || 'Unknown error');
    }
  } catch (error) {
    console.log('   ❌ Error:', error.message);
  }
}

async function testSearchByOPA() {
  console.log('\n🔍 Testing search by OPA account...');
  try {
    const url = `${BASE_URL}/search-certifications?opaAccount=${TEST_DATA.opaAccount}`;
    console.log(`   GET ${url}`);
    
    const response = await makeRequest(url);
    
    if (response.status === 200) {
      console.log('   ✅ Success:', `Found ${response.data?.length || 0} properties`);
    } else {
      console.log('   ❌ Failed:', response.status, response.data?.error || 'Unknown error');
    }
  } catch (error) {
    console.log('   ❌ Error:', error.message);
  }
}

async function testPropertyDetails() {
  console.log('\n🏠 Testing property details...');
  try {
    const url = `${BASE_URL}/property-details/${TEST_DATA.opaAccount}`;
    console.log(`   GET ${url}`);
    
    const response = await makeRequest(url);
    
    if (response.status === 200) {
      console.log('   ✅ Success: Property details retrieved');
      console.log('   📋 Property:', {
        address: response.data?.property_address,
        type: response.data?.cert_type,
        status: response.data?.compliance_status
      });
    } else if (response.status === 404) {
      console.log('   ⚠️  Property not found (expected for test OPA)');
    } else {
      console.log('   ❌ Failed:', response.status, response.data?.error || 'Unknown error');
    }
  } catch (error) {
    console.log('   ❌ Error:', error.message);
  }
}

async function testBulkSearch() {
  console.log('\n📊 Testing bulk search...');
  try {
    const url = `${BASE_URL}/bulk-search`;
    console.log(`   POST ${url}`);
    console.log(`   Body: ${TEST_DATA.bulkProperties.length} properties`);
    
    const response = await makeRequest(url, {
      method: 'POST',
      body: { properties: TEST_DATA.bulkProperties }
    });
    
    if (response.status === 200) {
      console.log('   ✅ Success: Bulk search completed');
      console.log('   📊 Results:', {
        requested: response.data?.totalRequested,
        found: response.data?.totalFound,
        errors: response.data?.totalErrors || 0
      });
    } else {
      console.log('   ❌ Failed:', response.status, response.data?.error || 'Unknown error');
    }
  } catch (error) {
    console.log('   ❌ Error:', error.message);
  }
}

async function testComplianceSummary() {
  console.log('\n📈 Testing compliance summary...');
  try {
    const url = `${BASE_URL}/compliance-summary`;
    console.log(`   GET ${url}`);
    
    const response = await makeRequest(url);
    
    if (response.status === 200) {
      console.log('   ✅ Success: Summary generated');
      console.log('   📊 Summary:', {
        total: response.data?.total,
        compliant: response.data?.inCompliance,
        nonCompliant: response.data?.nonCompliant,
        expiring: response.data?.expiringSoon
      });
    } else {
      console.log('   ❌ Failed:', response.status, response.data?.error || 'Unknown error');
    }
  } catch (error) {
    console.log('   ❌ Error:', error.message);
  }
}

async function testErrorHandling() {
  console.log('\n⚠️  Testing error handling...');
  try {
    // Test missing parameters
    const url = `${BASE_URL}/search-certifications`;
    console.log(`   GET ${url} (no parameters)`);
    
    const response = await makeRequest(url);
    
    if (response.status === 400) {
      console.log('   ✅ Success: Proper error handling for missing parameters');
    } else {
      console.log('   ❌ Unexpected response:', response.status);
    }
  } catch (error) {
    console.log('   ❌ Error:', error.message);
  }
}

async function testCORS() {
  console.log('\n🌐 Testing CORS headers...');
  try {
    const url = `${BASE_URL}/search-certifications?address=test`;
    const response = await makeRequest(url);
    
    const corsHeader = response.headers['access-control-allow-origin'];
    if (corsHeader) {
      console.log('   ✅ Success: CORS headers present');
      console.log('   📋 Allow-Origin:', corsHeader);
    } else {
      console.log('   ⚠️  Warning: CORS headers not found');
    }
  } catch (error) {
    console.log('   ❌ Error:', error.message);
  }
}

// Performance test
async function testPerformance() {
  console.log('\n⚡ Testing performance...');
  try {
    const url = `${BASE_URL}/search-certifications?address=${encodeURIComponent(TEST_DATA.address)}`;
    const startTime = Date.now();
    
    const response = await makeRequest(url);
    const endTime = Date.now();
    const duration = endTime - startTime;
    
    console.log(`   ⏱️  Response time: ${duration}ms`);
    
    if (duration < 5000) {
      console.log('   ✅ Performance: Good (< 5 seconds)');
    } else if (duration < 10000) {
      console.log('   ⚠️  Performance: Acceptable (< 10 seconds)');
    } else {
      console.log('   ❌ Performance: Slow (> 10 seconds)');
    }
  } catch (error) {
    console.log('   ❌ Error:', error.message);
  }
}

// Main test runner
async function runAllTests() {
  console.log('🧪 Philadelphia Lead Certification API Test Suite');
  console.log('================================================');
  console.log(`Testing against: ${BASE_URL}`);
  console.log(`Environment: ${process.env.NODE_ENV || 'development'}`);
  
  if (BASE_URL.includes('localhost')) {
    console.log('\n📝 Make sure to run "netlify dev" first for local testing');
  }

  // Run all tests
  await testSearchByAddress();
  await testSearchByOPA();
  await testPropertyDetails();
  await testBulkSearch();
  await testComplianceSummary();
  await testErrorHandling();
  await testCORS();
  await testPerformance();

  console.log('\n✨ Test suite completed!');
  console.log('\n💡 Tips:');
  console.log('   - For local testing: netlify dev');
  console.log('   - For production testing: NODE_ENV=production node test-functions.js');
  console.log('   - Check browser network tab for detailed debugging');
  console.log('   - View function logs in Netlify dashboard');
}

// Error handling for the test script itself
process.on('unhandledRejection', (reason, promise) => {
  console.error('❌ Unhandled Rejection at:', promise, 'reason:', reason);
  process.exit(1);
});

process.on('uncaughtException', (error) => {
  console.error('❌ Uncaught Exception:', error);
  process.exit(1);
});

// Run tests if this file is executed directly
if (require.main === module) {
  runAllTests().catch(error => {
    console.error('❌ Test suite failed:', error);
    process.exit(1);
  });
}

module.exports = {
  runAllTests,
  testSearchByAddress,
  testSearchByOPA,
  testPropertyDetails,
  testBulkSearch,
  testComplianceSummary,
  makeRequest
};